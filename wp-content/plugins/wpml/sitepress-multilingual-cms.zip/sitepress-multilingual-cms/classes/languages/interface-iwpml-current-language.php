<?php

interface IWPML_Current_Language {
	public function get_current_language();
	public function get_default_language();
	public function get_admin_language();
}